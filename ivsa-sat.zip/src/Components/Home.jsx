import React from 'react';
import Landingpage from './Landingpage';

const Home = () => {
    return (
        <div>
            <Landingpage></Landingpage>
        </div>
    );
}

export default Home;
